# 🇯🇵 日本株LSTM株価予測アプリ 📈

このアプリは、日本の上場株（トヨタ、ソニーなど）をLSTMとテクニカル指標（MA, RSI, MACD）で予測します。

## 実行方法

```bash
pip install -r requirements.txt
streamlit run app.py
```
